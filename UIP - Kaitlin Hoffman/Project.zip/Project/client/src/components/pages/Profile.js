import React, { useEffect, useState } from 'react';

const Profile = ({ username }) => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/user/profile/${username}`) // <-- CHANGED: fetch profile by username
      .then(res => {
        if (!res.ok) throw new Error('Profile not found');
        return res.json();
      })
      .then(data => {
        setProfile(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [username]);

  if (loading) return <p>Loading profile...</p>;
  if (!profile) return <p>User profile not found.</p>;

  return (
    <div>
      <h2>Profile: {profile.username}</h2>
      <p>Followers: {profile.followers.length}</p>
      <p>Following: {profile.following.length}</p>
    </div>
  );
};

export default Profile;
